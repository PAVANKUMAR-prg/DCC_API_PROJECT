import React, { useState } from 'react';
import styles from './EditUserModal.module.css'; // Import the CSS module

const EditUserModal = ({ user, onClose, onUpdate }) => {
    const [formData, setFormData] = useState({
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        role: user.role,
        password: user.password, // Reset password for security
        photo: null,
    });
    const [showPassword, setShowPassword] = useState(false); // State to toggle password visibility

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'photo') {
            setFormData({ ...formData, photo: files[0] });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const data = new FormData();
        data.append('id', formData.id);
        data.append('name', formData.name);
        data.append('email', formData.email);
        data.append('phone', formData.phone);
        data.append('address', formData.address);
        data.append('password', formData.password); // Include password
        data.append('role', formData.role);
        data.append('photoPath', '');
        if (formData.photo) {
            data.append('imageFile', formData.photo);
        }

        onUpdate(data);
        onClose();
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
            <div className={`${styles.modal} w-full max-w-md`}>
                <h2 className="text-2xl font-semibold mb-4 text-white">Edit User</h2>
                <form onSubmit={handleSubmit} className="space-y-4 overflow-y-auto max-h-[70vh]">
                    {/* Form Fields */}
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Name</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Email</label>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Phone</label>
                        <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Address</label>
                        <input
                            type="text"
                            name="address"
                            value={formData.address}
                            onChange={handleChange}
                            className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Password</label>
                        <div className="relative">
                            <input
                                type={showPassword ? 'text' : 'password'} // Toggle between text and password
                                name="password"
                                value={formData.password}
                                onChange={handleChange}
                                className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)} // Toggle visibility
                                className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-200"
                            >
                                {showPassword ? 'Hide' : 'Show'} {/* Toggle button text */}
                            </button>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Role</label>
                        <select
                            name="role"
                            value={formData.role}
                            onChange={handleChange}
                            className="w-full border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        >
                            <option value="user">User</option>
                            <option value="admin">Admin</option>

                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300">Profile Photo</label>
                        <input
                            type="file"
                            name="photo"
                            onChange={handleChange}
                            accept="image/*"
                            className="border border-gray-700 bg-gray-900 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500"
                        />
                    </div>
                </form>
                <div className="flex justify-end mt-4">
                    <button
                        type="button"
                        onClick={onClose}
                        className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 transition duration-200 mr-2"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        onClick={handleSubmit}
                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200"
                    >
                        Save
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EditUserModal;
