import React, { useEffect, useState } from 'react';
import axios from 'axios';
import EditUserModal from './EditUserModal';

const UserList = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedUser, setSelectedUser] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [sortOrder, setSortOrder] = useState("asc");
    const [currentPage, setCurrentPage] = useState(1);
    const usersPerPage = 6;

    const fetchUsers = async () => {
        try {
            const response = await axios.get('https://localhost:7157/api/User/GetAllUsers');
            setUsers(response.data);
        } catch (err) {
            setError(err.response.data.message || 'Error fetching users');
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm("Are you sure you want to delete this user?")) {
            try {
                await axios.delete(`https://localhost:7157/api/User/DeleteUsers?id=${id}`);
                setUsers(users.filter(user => user.id !== id));
            } catch (err) {
                setError(err.response.data.message || 'Error deleting user');
            }
        }
    };

    const handleUpdate = async (formData) => {
        try {
            const id = formData.get("id"); // Getting the ID from formData
            
            const response = await axios.put(`https://localhost:7157/api/User/UpdateUsers/${id}`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            if (response.status === 200) {
                alert("User updated successfully");
                fetchUsers(); // Refresh user list
            } else {
                console.error('Failed to update user:', response.statusText);
            }
        } catch (error) {
            console.error('Error updating user:', error.response ? error.response.data : error.message);
        }
    };
    
    

    const handleSearch = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
    };

    const handleSort = () => {
        const sortedUsers = [...users].sort((a, b) => 
            sortOrder === "asc" 
                ? a.name.localeCompare(b.name) 
                : b.name.localeCompare(a.name)
        );
        setUsers(sortedUsers);
        setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const filteredUsers = users.filter((user) =>
        user.name.toLowerCase().includes(searchTerm) ||
        user.email.toLowerCase().includes(searchTerm)
    );

    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

    const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

    if (loading) return <div className="text-white">Loading...</div>;
    
    return (
        <div className="container mx-auto mt-5 bg-gray-900 text-gray-200 p-5 rounded-lg">
            <h1 className="text-3xl font-bold mb-4">User List</h1>
            <div className="flex justify-between items-center mb-4">
                <input
                    type="text"
                    placeholder="Search users by name or email"
                    onChange={handleSearch}
                    className="border border-gray-700 bg-gray-800 text-white px-3 py-2 rounded focus:outline-none focus:ring focus:ring-blue-500 w-full md:w-1/2 lg:w-1/3"
                />
                <button
                    onClick={handleSort}
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition duration-200 ml-2"
                >
                    Sort by Name ({sortOrder === "asc" ? "Asc" : "Desc"})
                </button>
            </div>

            {filteredUsers.length === 0 ? (
                <div className="text-gray-400 text-center">
                    No users found. Please try a different search term.
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {currentUsers.map((user) => (
                        <div key={user.id} className="bg-gray-800 rounded-lg shadow-lg p-5 transform transition duration-300 hover:shadow-xl">
                            <img
                                src={user.photoPath ? `https://localhost:7157${user.photoPath}` : 'default-avatar.png'}
                                alt="User Profile"
                                className="w-full h-40 object-cover rounded mb-4"
                            />
                            <h2 className="text-xl font-bold">{user.name}</h2>
                            <p className="text-gray-300">{user.email}</p>
                            <p className="text-gray-300">{user.phone}</p>
                            <div className="flex justify-between mt-4">
                                <button
                                    onClick={() => setSelectedUser(user)}
                                    className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-200 w-1/2 mr-1"
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleDelete(user.id)}
                                    className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-red-700 transition duration-200 w-1/2 ml-1"
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <div className="flex justify-center mt-6 space-x-2">
                {Array.from({ length: totalPages }, (_, index) => (
                    <button
                        key={index}
                        onClick={() => setCurrentPage(index + 1)}
                        className={`px-3 py-1 rounded ${currentPage === index + 1 ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'} hover:bg-blue-700 transition duration-200`}
                    >
                        {index + 1}
                    </button>
                ))}
            </div>

            {selectedUser && (
                <EditUserModal
                    user={selectedUser}
                    onClose={() => setSelectedUser(null)}
                    onUpdate={handleUpdate}
                />
            )}
        </div>
    );
};

export default UserList;


