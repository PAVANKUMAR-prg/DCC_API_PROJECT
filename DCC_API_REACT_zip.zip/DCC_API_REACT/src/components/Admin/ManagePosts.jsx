import React from 'react';

const ManagePosts = () => {
  return (
    <div>
      <h3 className="text-lg font-semibold">Manage Posts</h3>
      {/* Add your manage posts functionality here */}
    </div>
  );
};

export default ManagePosts;
