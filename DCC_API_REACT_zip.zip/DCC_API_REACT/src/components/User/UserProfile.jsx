// // import React, { useEffect, useState } from 'react';
// // import { useUser } from '../Global/UserContext'; // Adjust the import path as necessary

// // function UserProfile() {
// //   const { user } = useUser(); // Get user from context
// //   const [loading, setLoading] = useState(true);
// //   const [error, setError] = useState(null);
// //   const [userData, setUserData] = useState(null);

// //   // Fetch user data from the API using the ID from context
// //   useEffect(() => {
// //     const fetchUser = async () => {
// //       if (!user) {
// //         setError('No user logged in');
// //         setLoading(false);
// //         return;
// //       }

// //       try {
// //         const response = await fetch(`https://localhost:7157/api/User/GetUserById/${user.id}`); // Ensure the user object has an id property
// //         if (!response.ok) {
// //           throw new Error('Failed to fetch user data');
// //         }
// //         const data = await response.json();
// //         setUserData(data);
// //       } catch (err) {
// //         setError(err.message);
// //       } finally {
// //         setLoading(false);
// //       }
// //     };

// //     fetchUser();
// //   }, [user]);

// //   if (loading) return <div>Loading...</div>;
// //   if (error) return <div>Error: {error}</div>;

// //   return (
// //     <div className="container mx-auto p-4">
// //       <h1 className="text-2xl font-bold mb-4">User Profile</h1>
// //       {userData ? (
// //         <div className="border rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow duration-200">
// //           <h2 className="text-xl font-semibold">{userData.name}</h2>
// //           <p className="text-gray-600">Email: {userData.email}</p>
// //           <p className="text-gray-600">Phone: {userData.phone}</p>
// //           <p className="text-gray-600">Address: {userData.address}</p>
// //           <p className="text-gray-600">Role: {userData.role}</p>
// //           <p className="text-gray-600">ImageUrl: {userData.PhotoPath}</p>

// //         </div>
// //       ) : (
// //         <p>No user data available</p>
// //       )}
// //     </div>
// //   );
// // }

// // export default UserProfile;

// import React, { useEffect, useState } from 'react';
// import { useUser } from '../Global/UserContext'; // Adjust the import path as necessary

// function UserProfile() {
//   const { user } = useUser(); // Get user from context
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [userData, setUserData] = useState(null);

//   // Fetch user data from the API using the ID from context
//   useEffect(() => {
//     const fetchUser = async () => {
//       if (!user) {
//         setError('No user logged in');
//         setLoading(false);
//         return;
//       }

//       try {
//         const response = await fetch(`https://localhost:7157/api/User/GetUserById/${user.id}`); // Ensure the user object has an id property
//         if (!response.ok) {
//           throw new Error('Failed to fetch user data');
//         }
//         const data = await response.json();
//         setUserData(data);
//       } catch (err) {
//         setError(err.message);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUser();
//   }, [user]);

//   if (loading) return <div>Loading...</div>;
//   if (error) return <div>Error: {error}</div>;
//   console.log(userData); // Confirm the entire object is as expected

//   console.log(userData.photoPath); // Check if the URL or path is correct

//   const baseUrl = "https://localhost:7157";


//   return (
//     <div className="container mx-auto p-4">
//       <h1 className="text-2xl font-bold mb-4">User Profile</h1>
//       {userData ? (
        
//         <div className="border rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow duration-200 flex items-center">
//           {userData.photoPath && (
//             <img
//               src={`https://localhost:7157${userData.photoPath}`} // Assumes PhotoPath is relative to the API base URL
//               alt="User Profile"
//               className="w-24 h-24 rounded-full mr-4 object-cover"
//             />
            
//           )}
//           <div>
//             <h2 className="text-xl font-semibold">{userData.name}</h2>
//             <p className="text-gray-600">Email: {userData.email}</p>
//             <p className="text-gray-600">Phone: {userData.phone}</p>
//             <p className="text-gray-600">Address: {userData.address}</p>
//             <p className="text-gray-600">Role: {userData.role}</p>
//           </div>
//         </div>
//       ) : (
//         <p>No user data available</p>
//       )}
//     </div>
//   );
// }

// export default UserProfile;

import React, { useEffect, useState } from 'react';
import { useUser } from '../Global/UserContext';

function UserProfile() {
  const { user } = useUser();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userData, setUserData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [updatedUser, setUpdatedUser] = useState({});
  const [imageFile, setImageFile] = useState(null);
  const [updateLoading, setUpdateLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false); // Toggle for password visibility

  useEffect(() => {
    const fetchUser = async () => {
      if (!user) {
        setError('No user logged in');
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`https://localhost:7157/api/User/GetUserById/${user.id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch user data');
        }
        const data = await response.json();
        setUserData(data);
        setUpdatedUser(data); // Prefill data, including password if needed
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [user]);

  const handleEditClick = () => {
    setIsEditing(true);
    setSuccessMessage("");
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedUser((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setImageFile(e.target.files[0]);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setUpdateLoading(true);
    setError(null);
    setSuccessMessage("");

    const formData = new FormData();
    Object.keys(updatedUser).forEach((key) => {
      formData.append(key, updatedUser[key]);
    });
    if (imageFile) {
      formData.append('imageFile', imageFile);
    }

    try {
      const response = await fetch(`https://localhost:7157/api/User/UpdateUsers/${user.id}`, {
        method: 'PUT',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to update user data');
      }

      const updatedData = await response.json();
      setUserData(updatedData.user);
      setIsEditing(false);
      setImageFile(null);
      setSuccessMessage("User profile updated successfully!");
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdateLoading(false);
    }
  };

  const toggleShowPassword = () => {
    setShowPassword((prev) => !prev);
  };

  if (loading) return <div>Loading...</div>;
  if (error && !isEditing) return <div>Error: {error}</div>;

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">User Profile</h1>
      {successMessage && <p className="text-green-500 mb-4">{successMessage}</p>}
      {isEditing ? (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <form onSubmit={handleUpdate} className="bg-white rounded-lg p-6 shadow-md w-full max-w-md mx-4 overflow-hidden">
            <h2 className="text-xl font-semibold mb-4">Edit User</h2>
            {error && <p className="text-red-500 mb-4">{error}</p>}
            <div className="mb-4">
              <input type="text" name="name" value={updatedUser.name} onChange={handleChange} required className="border rounded w-full p-2" placeholder="Name" />
            </div>
            <div className="mb-4">
              <input type="email" name="email" value={updatedUser.email} onChange={handleChange} required className="border rounded w-full p-2" placeholder="Email" />
            </div>
            <div className="mb-4">
              <input type="text" name="phone" value={updatedUser.phone} onChange={handleChange} required className="border rounded w-full p-2" placeholder="Phone" />
            </div>
            <div className="mb-4">
              <input type="text" name="address" value={updatedUser.address} onChange={handleChange} required className="border rounded w-full p-2" placeholder="Address" />
            </div>
            <div className="mb-4">
              <input 
                type={showPassword ? "text" : "password"} 
                name="password" 
                value={updatedUser.password || ""} 
                onChange={handleChange} 
                required 
                className="border rounded w-full p-2" 
                placeholder="Password" 
              />
              <label className="flex items-center mt-2">
                <input type="checkbox" onChange={toggleShowPassword} checked={showPassword} />
                <span className="ml-2">Show Password</span>
              </label>
            </div>
            <div className="mb-4">
              <input type="file" onChange={handleFileChange} className="border rounded w-full p-2" />
            </div>
            <div className="flex justify-end">
              <button type="submit" className="bg-blue-500 text-white rounded px-4 py-2" disabled={updateLoading}>
                {updateLoading ? 'Updating...' : 'Update'}
              </button>
              <button type="button" onClick={() => setIsEditing(false)} className="ml-2 border rounded px-4 py-2">
                Cancel
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div className="border rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow duration-200 flex items-center">
          {userData.photoPath && (
            <img
              src={`https://localhost:7157${userData.photoPath}`}
              alt="User Profile"
              className="w-24 h-24 rounded-full mr-4 object-cover"
            />
          )}
          <div>
            <h2 className="text-xl font-semibold">{userData.name}</h2>
            <p className="text-gray-600">Email: {userData.email}</p>
            <p className="text-gray-600">Phone: {userData.phone}</p>
            <p className="text-gray-600">Address: {userData.address}</p>
            <p className="text-gray-600">Role: {userData.role}</p>
            <button onClick={handleEditClick} className="bg-yellow-500 text-white rounded px-4 py-2 mt-2">Edit</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserProfile;


