// import React from 'react';

// const About = () => {
//   return (
//     <div className="container mx-auto p-6">
//       {/* Panel Header */}
//       <div className="bg-white shadow-md rounded-t-lg p-4">
//         <h1 className="text-2xl font-bold">About Us</h1>
//       </div>

//       {/* Panel Body */}
//       <div className="bg-orange-300 shadow-md rounded-b-lg p-6">
//         <div className="flex flex-col md:flex-row">
//           {/* Image Section */}
//           <div className="md:w-5/12 p-4">
//             <img
//               //src= "https://images.pexels.com/photos/17950464/pexels-photo-17950464/free-photo-of-person-on-bicycle-on-crosswalk.jpeg" // Update this path
//               src='https://i.pinimg.com/736x/d5/8b/e8/d58be8784e8d9af68a76e135ce7882ae.jpg'
//               alt="Cycling Club"
//               className="img-responsive rounded-md shadow-md"
//             />
//           </div>

//           {/* Text Section */}
//           <div className="md:w-7/12 p-4">
//             <p className="text-lg text-justify indent-8">
//               A group of enthusiasts with a passion for nature, health, and
//               friendship started cycling a few years ago. With a common interest,
//               we founded the “Davanagere Cycling Club” with the passion “Pedal With Pride.”
//             </p>

//             <p className="mt-4 text-lg text-justify indent-8">
//               We started riding every alternate day with the motto of the Great Cyclist
//               Mr. Eddy Merckx: “Ride as much or as little, or as long or as short as you feel,
//               but ride.”
//             </p>

//             <p className="mt-4 text-lg text-justify indent-8">
//               Very soon, the movement gained momentum with members of all ages, and we began
//               connecting and inspiring many to join. Today, it’s one of the most premium
//               cycling clubs in Davangere, boasting members from various professions, including
//               businessmen, doctors, professors, students, and more.
//             </p>

//             <p className="mt-4 text-lg text-justify indent-8">
//               Our club is affiliated with Audax India Randonneurs (AIR), and we regularly organize
//               events like 100km to 600km brevets. We also successfully organized the MTB Challenge
//               in May 2023.
//             </p>

//             <p className="mt-4 text-lg text-justify indent-8">
//               The First Sunday of the Month (FSOM) Ride was introduced as a platform for new riders
//               to enjoy the pleasure of cycling in nature.
//             </p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default About;

//00000000000000000000000000000000000000000000000000000000000000000000
// import React, { useState, useEffect } from 'react';

// const About = () => {
//   // Carousel index state
//   const [currentIndex, setCurrentIndex] = useState(0);

//   // List of images for the carousel
//   const images = [
//     './public/images/groupImage-4.jpg',
//     './public/images/groupImage-2.jpg',
//     './public/images/groupImage-3.webp',
//   ];

//   // Auto-scroll functionality for the carousel
//   useEffect(() => {
//     const interval = setInterval(() => {
//       nextSlide();
//     }, 3000); // Change slide every 3 seconds

//     return () => clearInterval(interval); // Cleanup interval on component unmount
//   }, [currentIndex]);

//   // Function to go to the next image
//   const nextSlide = () => {
//     setCurrentIndex((currentIndex + 1) % images.length);
//   };

//   // Function to go to the previous image
//   const prevSlide = () => {
//     setCurrentIndex((currentIndex - 1 + images.length) % images.length);
//   };

//   return (
//     <div className=" max-w-7xl container mx-auto px-6 py-10 bg-black text-center ">
//       {/* Header Section */}
//       <div className="mb-10">
//         <h1 className="text-4xl font-bold text-white">About Davangere Cycling Club</h1>
//         <p className="text-xl text-gray-400 mt-4 max-w-2xl mx-auto">
//           Join our journey to inspire, connect, and foster a love for cycling. Embrace the outdoors, build friendships, and pedal towards a healthier future.
//         </p>
//       </div>
      
//       {/* Carousel Section */}
//       <div className="relative w-full md:w-2/3 lg:w-1/2 mx-auto mb-10">
//         <div className="overflow-hidden rounded-lg shadow-lg">
//           <img
//             src={images[currentIndex]}
//             alt={`Slide ${currentIndex + 1}`}
//             className="w-full h-64 md:h-80 object-cover transition-transform duration-500"
//           />
//         </div>
//         <button
//           onClick={prevSlide}
//           className="absolute top-1/2 transform -translate-y-1/2 left-0  text-orange-600 text-white p-2 rounded-full"
//         >
//           &lt;
//         </button>
//         <button
//           onClick={nextSlide}
//           className="absolute top-1/2 transform -translate-y-1/2 right-0   text-orange-600 text-white p-2 rounded-full "
//         >
//           &gt;
//         </button>
//         <div className="flex justify-center mt-4 space-x-2">
//           {images.map((_, idx) => (
//             <button
//               key={idx}
//               className={`h-2 w-2 rounded-full ${currentIndex === idx ? 'bg-blue-500' : 'bg-gray-400'}`}
//               onClick={() => setCurrentIndex(idx)}
//             />
//           ))}
//         </div>
//       </div>

//       {/* Mission, Vision, and History Sections */}
//       <div className="space-y-8">
//         {/* Mission Section */}
//         <div className="bg-white shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl">
//           <h2 className="text-3xl font-semibold text-orange-600 mb-4">Our Mission</h2>
//           <p className="text-lg text-gray-700">
//             At Davangere Cycling Club, our mission is to promote health, unity, and adventure. We foster a supportive environment for cyclists of all skill levels to enjoy the open road and push their limits.
//           </p>
//         </div>

//         {/* Vision Section */}
//         <div className="bg-white shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl">
//           <h2 className="text-3xl font-semibold  text-orange-600 mb-4">Our Vision</h2>
//           <p className="text-lg text-gray-700">
//             Our vision is to create a thriving cycling community that embraces the outdoors, builds lasting friendships, and encourages a healthy lifestyle for generations to come.
//           </p>
//         </div>

//         {/* History Section */}
//         <div className="bg-white shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl">
//           <h2 className="text-3xl font-semibold text-orange-600 mb-4">Our History</h2>
//           <p className="text-lg text-gray-700">
//             Founded by a group of passionate cyclists, Davangere Cycling Club began with the simple goal of enjoying nature and connecting with like-minded individuals. Over the years, our community has grown, hosting events, group rides, and charitable activities, making a positive impact on society.
//           </p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default About;

//-----------------------------------------------------------------------------------------------------------------------
import React, { useState, useEffect } from 'react';

const About = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const images = [
    './public/images/groupImage-4.jpg',
    './public/images/groupImage-2.jpg',
    './public/images/groupImage-3.webp',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 3000);

    return () => clearInterval(interval);
  }, [currentIndex]);

  const nextSlide = () => {
    setCurrentIndex((currentIndex + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentIndex((currentIndex - 1 + images.length) % images.length);
  };

  return (
    <div className="max-w-7xl container mx-auto px-6 py-10 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 text-center">
      {/* Header Section */}
      <div className="mb-10">
        <h1 className="text-4xl font-bold text-white">About Davangere Cycling Club</h1>
        <p className="text-xl text-gray-300 mt-4 max-w-2xl mx-auto">
          Join our journey to inspire, connect, and foster a love for cycling. Embrace the outdoors, build friendships, and pedal towards a healthier future.
        </p>
      </div>

      {/* Carousel Section */}
      <div className="relative w-full md:w-2/3 lg:w-1/2 mx-auto mb-10">
        <div className="overflow-hidden rounded-lg shadow-lg relative">
          <img
            src={images[currentIndex]}
            alt={`Slide ${currentIndex + 1}`}
            className="w-full h-64 md:h-80 object-cover transition-opacity duration-700 opacity-90 hover:opacity-100"
          />
          <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black to-transparent p-4 text-left text-white opacity-90">
            <h3 className="text-xl font-semibold">Image {currentIndex + 1}</h3>
            <p className="text-sm">Cycling together for a healthier, happier life.</p>
          </div>
        </div>
        <button
          onClick={prevSlide}
          className="absolute top-1/2 transform -translate-y-1/2 left-0  text-white p-2 rounded-full shadow-md hover:scale-105 transition-transform"
        >
          &lt;
        </button>
        <button
          onClick={nextSlide}
          className="absolute top-1/2 transform -translate-y-1/2 right-0  text-white p-2 rounded-full shadow-md hover:scale-105 transition-transform"
        >
          &gt;
        </button>
        <div className="flex justify-center mt-4 space-x-2">
          {images.map((_, idx) => (
            <button
              key={idx}
              className={`h-2 w-2 rounded-full transition-all duration-300 ${currentIndex === idx ? 'bg-blue-500 scale-125' : 'bg-gray-500'}`}
              onClick={() => setCurrentIndex(idx)}
            />
          ))}
        </div>
      </div>

      {/* Mission, Vision, and History Sections */}
      <div className="space-y-8">
        {/* Mission Section */}
        <div className="bg-gray-800 shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl transition transform hover:scale-105 hover:shadow-xl duration-500 opacity-90 hover:opacity-100">
          <h2 className="text-3xl font-semibold text-blue-500 mb-4 animate-fadeIn">Our Mission</h2>
          <p className="text-lg text-gray-300">
            At Davangere Cycling Club, our mission is to promote health, unity, and adventure. We foster a supportive environment for cyclists of all skill levels to enjoy the open road and push their limits.
          </p>
        </div>

        {/* Vision Section */}
        <div className="bg-gray-800 shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl transition transform hover:scale-105 hover:shadow-xl duration-500 opacity-90 hover:opacity-100">
          <h2 className="text-3xl font-semibold text-blue-500 mb-4 animate-fadeIn">Our Vision</h2>
          <p className="text-lg text-gray-300">
            Our vision is to create a thriving cycling community that embraces the outdoors, builds lasting friendships, and encourages a healthy lifestyle for generations to come.
          </p>
        </div>

        {/* History Section */}
        <div className="bg-gray-800 shadow-md rounded-lg p-6 mb-10 mx-auto max-w-3xl transition transform hover:scale-105 hover:shadow-xl duration-500 opacity-90 hover:opacity-100">
          <h2 className="text-3xl font-semibold text-blue-500 mb-4 animate-fadeIn">Our History</h2>
          <p className="text-lg text-gray-300">
            Founded by a group of passionate cyclists, Davangere Cycling Club began with the simple goal of enjoying nature and connecting with like-minded individuals. Over the years, our community has grown, hosting events, group rides, and charitable activities, making a positive impact on society.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
