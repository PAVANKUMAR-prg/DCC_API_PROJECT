import React from 'react';
import './ParallaxBanner.css'; // We'll create this CSS next

const ParallaxBanner = () => (
  <div className="parallax-section">
    <h2 className="parallax-text">Join Our Rides & Adventures </h2>
 
  </div>
);

export default ParallaxBanner;
